<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['idUsuario'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idUsuario = $_SESSION['idUsuario'];
    $idVeiculo = $_POST['idVeiculo'];

    // Criar tabela favoritos se não existir
    $conn->query("CREATE TABLE IF NOT EXISTS Favorito (
        idFavorito INT AUTO_INCREMENT PRIMARY KEY,
        idUsuario INT NOT NULL,
        idVeiculo INT NOT NULL,
        data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario),
        FOREIGN KEY (idVeiculo) REFERENCES Veiculo(idVeiculo)
    )");

    $stmt = $conn->prepare("INSERT INTO Favorito (idUsuario, idVeiculo) VALUES (?, ?)");
    $stmt->bind_param("ii", $idUsuario, $idVeiculo);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo "<script>alert('Veículo adicionado aos favoritos!'); window.location='catalogo.php';</script>";
}
?>
