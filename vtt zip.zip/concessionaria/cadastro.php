<?php
// Ativar exibição de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'conexao.php';

$mensagem = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $conn->real_escape_string($_POST['nome']);
    $telefone = $conn->real_escape_string($_POST['telefone']);
    $email = $conn->real_escape_string($_POST['email']);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

    if ($nome && $telefone && $email && $_POST['senha']) {
        $sql = "INSERT INTO Usuario (nome, telefone, email, senha) VALUES ('$nome', '$telefone', '$email', '$senha')";
        if ($conn->query($sql)) {
            $mensagem = "Cadastro realizado com sucesso!";
        } else {
            $mensagem = "Erro ao cadastrar: " . $conn->error;
        }
    } else {
        $mensagem = "Preencha todos os campos corretamente!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - Concessionária Viriatto</title>
    <link rel="stylesheet" href="Desing.css">
    <script src="Web.js"></script>
</head>
<body class="cadastro-bg">

<div class="container">
    <h2>Cadastro de Usuário</h2>

    <?php if($mensagem) { echo "<p class='mensagem'>$mensagem</p>"; } ?>

    <form method="POST" action="" class="formulario">
        <label>Nome:</label>
        <input type="text" name="nome" id="nome" placeholder="Seu nome" required>

        <label>Telefone:</label>
        <input type="text" name="telefone" id="telefone" placeholder="Seu telefone" required>

        <label>Email:</label>
        <input type="email" name="email" id="email" placeholder="Seu email" required>

        <label>Senha:</label>
        <input type="password" name="senha" id="senha" placeholder="Sua senha" required>

        <button type="submit" onclick="Cadastrar()">Cadastrar</button>
        <button type="reset" onclick="Limpar()">Limpar</button>
    </form>

    <a href="PaginaWeb.html"><button class="voltar">Voltar</button></a>
</div>

</body>
</html>
