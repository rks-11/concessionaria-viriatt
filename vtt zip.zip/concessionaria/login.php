<?php
session_start();
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $stmt = $conn->prepare("SELECT idUsuario, senha, nome FROM Usuario WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($idUsuario, $senhaHash, $nome);
    $stmt->fetch();

    if ($senha && password_verify($senha, $senhaHash)) {
        $_SESSION['idUsuario'] = $idUsuario;
        $_SESSION['nome'] = $nome;
        header("Location: catalogo.php");
    } else {
        echo "<script>alert('Email ou senha incorretos!'); history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - Concessionária Viriatto</title>
    <link rel="stylesheet" href="Desing.css">
</head>
<body class="cadastro-bg">
<div class="container">
    <h2>Login</h2>
    <form method="POST" action="" class="formulario">
        <label>Email:</label>
        <input type="email" name="email" placeholder="Seu email" required>
        <label>Senha:</label>
        <input type="password" name="senha" placeholder="Sua senha" required>
        <button type="submit">Entrar</button>
    </form>
    <a href="PaginaWeb.html"><button class="voltar">Voltar</button></a>
</div>
</body>
</html>
