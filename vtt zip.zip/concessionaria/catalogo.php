<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Catálogo de Veículos</title>
<style>
/* Reset e fonte */
* { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
body { background: linear-gradient(120deg,#e3e3e3,#cfcfcf,#e3e3e3); color: #222; padding-bottom: 50px; }

/* Header */
header { text-align:center; padding:40px 20px; background:#2c3e50; color:white; margin-bottom:20px; border-bottom:4px solid #1a252f; }
header h1 { font-size:38px; margin-bottom:10px; }

/* Filtros */
.filtros { display:flex; justify-content:center; gap:15px; margin-bottom:30px; flex-wrap: wrap; }
.filtros button { padding:10px 20px; border:none; border-radius:8px; background:#1abc9c; color:white; font-weight:bold; cursor:pointer; transition:0.3s; }
.filtros button:hover { background:#16a085; transform: scale(1.05); }

/* Container */
.container { width:90%; max-width:1200px; margin:0 auto; }

/* Catalogo */
.catalogo { display:flex; flex-wrap:wrap; justify-content:center; gap:25px; margin-bottom:30px; }
.catalogo-item { background:#fff; padding:15px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.2); width:300px; text-align:center; transition: all 0.3s ease; position:relative; }
.catalogo-item:hover { transform: translateY(-10px); box-shadow:0 10px 20px rgba(0,0,0,0.3); }
.catalogo-item img { width:100%; border-radius:8px; margin-bottom:10px; transition: transform 0.3s ease; }
.catalogo-item img:hover { transform: scale(1.05); }
.catalogo-item p { margin:5px 0; position: relative; cursor: default; }
.catalogo-item p:hover::after { content: attr(data-info); position: absolute; bottom: 120%; left:50%; transform: translateX(-50%); background:#2c3e50; color:white; padding:5px 10px; border-radius:6px; white-space: nowrap; font-size:14px; opacity:0.9; }

/* Botão voltar */
.voltar { display:block; margin:30px auto; background: linear-gradient(45deg, #c0392b, #e74c3c); color:white; padding:12px 30px; border-radius: 10px; font-size: 16px; border:none; cursor:pointer; transition: all 0.3s ease; text-decoration:none; text-align:center; width:150px; }
.voltar:hover { background: linear-gradient(45deg, #e74c3c, #c0392b); transform: scale(1.05); }
</style>
</head>
<body>

<header>
    <h1>Catálogo de Veículos</h1>
</header>

<div class="filtros">
    <button onclick="filtrar('Popular')">Populares</button>
    <button onclick="filtrar('Sedan')">Sedans</button>
    <button onclick="filtrar('SUV')">SUVs</button>
    <button onclick="filtrar('Esportivo')">Esportivos</button>
    <button onclick="filtrar('Clássico')">Clássicos</button>
    <button onclick="filtrar('Todos')">Todos</button>
</div>

<section class="container">

    <div class="catalogo">
        <!-- Populares -->
        <div class="catalogo-item" data-tipo="Popular">
            <img src="https://garagem360.com.br/wp-content/uploads/2023/12/celta.jpg" alt="Chevrolet Celta">
            <p data-info="108.000 km">Chevrolet Celta 2012</p>
            <p data-info="Preço: R$ 20.000">Preço: R$ 20.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Popular">
            <img src="https://s2-autoesporte.glbimg.com/Q7qIOQinN4y6nyywCabeT-PqCCA=/0x0:620x413/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_cf9d035bf26b4646b105bd958f32089d/internal_photos/bs/2020/5/q/NMBTGiRG6HQ9UTxXs30g/2016-09-14-unosporting.jpg" alt="Fiat Uno Sporting">
            <p data-info="62.140 km">Fiat Uno Sporting 2017</p>
            <p data-info="Preço: R$ 40.000">Preço: R$ 40.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Popular">
            <img src="https://img1.icarros.com/dbimg/galeriaimgmodelo/2/41019_1.jpg" alt="Volkswagen Gol">
            <p data-info="70.122 km">Volkswagen Gol Rallye 2016</p>
            <p data-info="Preço: R$ 45.000">Preço: R$ 45.000</p>
        </div>

        <!-- Sedans -->
        <div class="catalogo-item" data-tipo="Sedan">
            <img src="https://cdn.autopapo.com.br/box/uploads/2023/10/03134939/toyota-corolla-2024-portal.jpg" alt="Toyota Corolla 2024">
            <p data-info="5.000 km">Toyota Corolla 2024</p>
            <p data-info="Preço: R$ 160.000">Preço: R$ 160.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Sedan">
            <img src="https://cdn.motor1.com/images/mgl/G32mV1/s3/volkswagen-jetta-gli-2023-brasil.jpg" alt="Volkswagen Jetta GLI 2023">
            <p data-info="6.000 km">Volkswagen Jetta GLI 2023</p>
            <p data-info="Preço: R$ 210.000">Preço: R$ 210.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Sedan">
            <img src="https://images.dealer.com/ddc/vehicles/2025/Audi/A4/Sedan/still/front-left/front-left-640-en_US.jpg" alt="Audi A4 Sedan">
            <p data-info="0 km">Audi A4 Sedan 2025</p>
            <p data-info="Preço: R$ 350.990">Preço: R$ 350.990</p>
        </div>

        <!-- SUVs -->
        <div class="catalogo-item" data-tipo="SUV">
            <img src="https://mundodoautomovelparapcd.com.br/wp-content/uploads/2019/07/toyota_sw4_1.jpg" alt="Toyota Hilux SW4">
            <p data-info="2.000 km">Toyota Hilux SW4 2024</p>
            <p data-info="Preço: R$ 310.000">Preço: R$ 310.000</p>
        </div>
        <div class="catalogo-item" data-tipo="SUV">
            <img src="https://file.kelleybluebookimages.com/kbb/base/evox/CP/53228/2024-Land%20Rover-Range%20Rover%20Velar-front_53228_032_2400x1800_1AA_nologo.png" alt="Range Rover Velar">
            <p data-info="3.000 km">Range Rover Velar 2024</p>
            <p data-info="Preço: R$ 540.000">Preço: R$ 540.000</p>
        </div>
        <div class="catalogo-item" data-tipo="SUV">
            <img src="https://www.webmotors.com.br/imagens/prod/379653/PORSCHE_CAYENNE_4.0_V8_GASOLINA_GTS_COUPE_AWD_TIPTRONIC_S_37965313490371126.webp?s=fill&w=170&h=125&t=true" alt="Porsche Cayenne">
            <p data-info="0 km">Porsche Cayenne 2025</p>
            <p data-info="Preço: R$ 900.000">Preço: R$ 900.000</p>
        </div>

        <!-- Esportivos -->
        <div class="catalogo-item" data-tipo="Esportivo">
            <img src="https://www.autogiz.com/product_images/jpeg/2025-Dodge-Challenger-Hellcat-Black-Ghost.jpg" alt="Dodge Challenger">
            <p data-info="0 km">Dodge Challenger SRT Hellcat 2025</p>
            <p data-info="Preço: R$ 1.500.000">Preço: R$ 1.500.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Esportivo">
            <img src="https://www.balcaoautomotivo.com/wp-content/uploads/2023/08/Design-sem-nome-2023-08-21T105306.537.png" alt="Mustang GTD">
            <p data-info="0 km">Mustang GTD 2025</p>
            <p data-info="Preço: R$ 2.000.000">Preço: R$ 2.000.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Esportivo">
            <img src="https://i.ytimg.com/vi/uNMGR-L1BKk/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLD2k0-ruLjkrCEQeMzdrbOSWBLTzA" alt="Porsche Panamera">
            <p data-info="0 km">Porsche Panamera 2025</p>
            <p data-info="Preço: R$ 1.250.000">Preço: R$ 1.250.000</p>
        </div>

        <!-- Clássicos brasileiros -->
        <div class="catalogo-item" data-tipo="Clássico">
            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhAQERIVFhAPFRUPFRYPGBUVEBUPFhUWFhUWFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGisdHx0tLS0tLSstLSstLS0tLS0tLS0tLS0tLSstKy0tLS0tLS0tLS0tLS0rLS0tKy0tLS0tK//AABEIALcBEwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIDBAUGBwj/xABIEAABBAADAwcFDgQFBAMAAAABAAIDEQQSIQUxUQYTIkFhcYEHkaGx0RQVMkJSU1RicpKTwdLwFyOC0xYzQ8Lhc4OisjSz8f/EABgBAQEBAQEAAAAAAAAAAAAAAAABAgME/8QAIBEBAQEBAAICAwEBAAAAAAAAAAERAhIhAxMxQVFhof/aAAwDAQACEQMRAD8A2wCdKaYC0IUnSnSKQQpOlIBOkEKTpSpOkEKRlU6TpBDKjKp0ikEMqMqnSKQQyoyqdIpBXlRlVlIpBXlRlVlIpBXlRlVmVFIK8qWVWZUZUFeVPKp5exGXsQQyoyqzL2Iydioryp5VZzfYnzaCvKjKrREpCJBTlRlV4iUhEERj5ULI5oIQYtJ0iuxSpRUaTpPKnlQRpOlINTyoIUnSnlRlQQpOlPKnlQV0ilblRlQVUnlVuVGVBVlRlVuVPKgpyp5FbSKQVZEZFbSKQV5EZFbSKVFeRGRWUikEMiA1TpOlBDKilOkUqIUnSnlRlREaTAUqTpBGkUp0nSCFIU8qEGHlRlUgnSio5U8qlSKQKk6TpMBAqRSlSKQRpOk6RSBUilKkUgVIpSpBCCNIpSpFII0nSdIpAqRSlSKVEaTpOk6QRpFKVJ5UEaTpSyp5VBCkUp5U8qorpOlZlRlREKRSsyp0gryphqspOkFeVCspCDApFKwsUaUCpOk6TpFKkUpUikCpOk6TpBGkUpUikCpFKSECpFJoQKkUoc83qN9yk11rN+Tmftqc2nSdKyOMFZcOFB4LH3cr9dYFIpbyLADgspmz28FPu/w8HNUil1IwLeAT97mfJHmV+3/DwcsAnS6R+yo/k+bRY0uxm/FJ9as+WJ4tLSKWZPs57Oqx2exYtLcsv4ZsKk6TpOlpEaTpSpFIFSKUqRSBUnSdJFAISQporcxVOYspRc1BiUhXuYqy1FRQmhAJpJoBCE0AhCjLIGgucaa0EknqAQYO2trx4SMySHuHWT+yPOBqSAuA2lynxc0r2RBpaw10CHNriC00O/MVZtiY42cl181Ed31hYy+Go78/EKGzowJZ8oADebYABQoNv81ndS9YBLiT1P7pJmkeYMPrWLjW4gDNTA1oJIaczncB0h6uK3dLD2n0WGS9YukL1B1G8eATGZ3WlwG0pHlsbWNLz1uLmk0L6jotm3G7QiIdES2upjyR90u1XNQYl7p+dOjnF8nRFNz2SQANw/Jdy1Zntrrqx6ZyF2pJisKyWYVKC5jtKst667iFsNr7XiwzXOlkDAxpe4NaZJRGN7i1oOQabyCO5ank9OMLgg93VG/Em+0ksB79PurzgYiXFYwmRxc3FxYjDEdTTJBIGgD7WXXfouc53W71mR1WK8qWBHwG4mXt1jHmsD0LFj8pUcrskWAzkanO8GgdxcSKHX19RXlGCeHNB4i1stj4z3PIXO/ypABJ9Ui8sndrR7NepanES9V65svlfE+SOOXCMjEpyhzA1zQ4AmnaaaAm92m+6BzeWnKP3CYQI2HnQ86szHokD5Ta+EOK4J82SXDa010zLPFmYAjzE+ZdN5SYecwuGm62ubfGpGa+lg86l5k6wnV8dQwflEiJAfFl7Yy5h82rfOVv8NjocULieC4i6dQkPGq6Lx3edeOBivw2IdGbY6iCDpx6r9u/gr9ee56Zny/16yW1oilgcmtr+7Yjmrn4qDuJHUT+R7+BWxAW+O99X8tWfuFSdJ0nS2yjSdJ0ikCKrKm9QpSqVJp0hB5X/FiX6LH+I79KZ8rEv0WP8R36Vxv+H8T81/5M/UkdgYn5o/eZ+pTR2R8q0v0WP8R36VWfKpL9Fj/Ed+lcidgYn5o/eZ+pI7BxPzR+8z9SaOu/inJ9FZ4SO/Sl/FSX6Kz8R36FyDthYj5o+dntUTsPEfNH7zPamjsf4py/RWfiu/Qn/FST6Iz8V36FxfvLiPmj52+1HvNiPmj52+1NHafxUk+iM/Fd+hSHlUk+iN/FP6Fx2E5O4uU1HA4/dDR3kmgul2f5OJnUZ52MHyYgZHV3nKAfOp5LlZrvKo/qwjfGU/oW52ttueWORnNtb0miNzHF/OE0RpWgF5uu8hV+zfJxgYgDMHvO/wDnONn/ALbMorvXV4eKKMZYoWgfWAPo3LHXyRqcV5js7CYuskeF6IvpPeBfbW+6C2GzeT+O6TzHGwzHnC17nOe3QAA5RW4XoTvXotOPXQ7NPUptw19vnK535b+l+qOFZyfxvWYfNJ6xaxsdybxs2eEMiDcoJe57mgmz0WgssnQa6DXevTIsF2LKZgq36d+nrU+3o+vl4j/hzF4RzHuwzpMmYjmHNNhzQ02aOg86z9jyy4mVsLYJGWQHmTQNb1kOGhXrrpYGGnTRg8C4WoyU98Zjp0bbL3UbGnRDXbiN5PcOK1PkuJeI5/lmyX3OIoIy7nJY4Dl0aImMc/U9QzaeC5XE7LmwM+Ce/L0ZoHyVfQbna47xqK0J01NUvQMPhHSvkbI85Q1ha0AU2a3Oc8Xv1NUeGlFZp2S12smZ5qt5bw1trr6uKvHcnJ1xt188yYbmJ54TuhkkjA+w8t/JWxvFhe9v5NYIuc92EhL3Euc6Roc5zibJc42SSVYzYmDbuwuGH/bj/Sr5+vwni8X2eybI6GFzXNILWsdedljdG4bxwaRpxqq9V5T4J02AkjosflzjdmBY8OA17CR4rex4eFmrIo21rbGAV5go+7GvylpzB11lqiOw3Sz10s5x4d7yv+Nzx+831AIGxAPiyeLpL9a9uI4QDx5sKOdw3QgdzmJ9jP1f6815C4N0OLBaXFr2Fha8kkdeYa8B612fKCeSGKSaKPnHsGbm7y5q4GjrXZroto/Eu64n/wBJjP8AuWJPiG7ndGwdJOjY66O4rN6u66TnJjzEeVk/Qx+Mf7aD5WHdWDHjMf7a5/lhyZlixUvMxl0TzzjS2qGbUjfx17iFpveLE1/ku87favROtmudmO5HlYd9DH4x/tpfxZf9Db+Mf7a4Q7GxHzLvR7Ue82I+Zd6ParqO4PlZf9Db+Kf0JfxZf9Db+Mf7a4X3mxHzLvR7U/eXEfNO9HtU0d0PKw76IPxT+hC4T3lxHzTvR7UJo7/rU1Ck1hTpACQCkEES1QcxTcSr8PDm1fmazjV+akGtmIa0uO4arYbP2e14bIXAxuGYBu8nrB4VWq2M+GjOWJgBa4ZnO320a6Hhu86zYsLQAqgBQA3AcApG8ghNANaKG4Bq2GHGXd8Ljw7vasbDM+Nx0H2f+fYspilmtL2DrO/tWTGsVhWDPtUF2Rj2tG4vd8HtDflHxodu5ZvJrbY3aEWHYXyvAaKHWSSdAABqSl77A0I8urRJb3Ucp4MALiR1ggLFj2DA4XKOdcd5mOYnw3AdgAWxw0TIwGRtDWtFANFaLm1+kmMc6i6Z57IWiNniX24d4KvEMXzTHf8AWL5j4F50V2GrjXarH4hl5C4XwJAefDem/wAQosQWim00cGNYB6lI4lx+M7wcR6lRNDWrdR6QoMmIGhru3+dZ8quRjbIiLQ0m9x3uJBFmr11K2okHyR5lq8C7o/1PHme4LLzp5GMxsvAAeAVjZh1rBDlMOKuph7Uh55hYCW3w1vQinA6Ea7itPs3YfNOjc51iH4IoDr00AAFWdwW4zlQkdoVfKmLy9RLlUXKLnrOqm950AFucaA7e3s3nwWTHh2t13uO9x3n2DsVOAA6bzv8AgN9bj5wB4FYfKPbkOChM0zqF5QBq97+pjB1n97gStSINqbLgnFPaLG5zdHDuPtXDbZ2Q7DH5UbtGuHjoeBWg2l5S8a51xRRMj6mvt7yOok5mjwAW85L8t2Y+8LiowyVw0onm31rperXDfXpW55c/lm5Wqd+/OglZW08PzMkjCdG04H6h3E+keFrHljLSQQQRoQ4UQe0LrrFmIhFpBFKCVpqOVCIZCdItNUKkaphSiYXOodf/ADaC7BYfOXHeGNzVxNgAechddDs2MxdoZ0y6nairIAPfp2ebn8C2KJj5pJAGNLWnMOq7Oh30QOzVZcWMa/NAHEssPkYHMDwDqAW5gWXVZuFrcRLZOF/ltefjAltfNucXNrsylqyMV0QGgWXnLpWg6zr2LIw2KDm6gAg7gWfBrQAA+FBQc93OWSOay0Bpeaxrx46LEdFgj0SOmqJA9wIjBzEaWDXbvFblr8QZZ2FsbXg04PcGnogHLdjcTp3Cz1UrlLWJisc6V5jjIEbTzbnk00vJAy5uA3lZzdnOax7zldkqm+NNINaC636G1rpg1lQRsORjctkaburt1W1wxdMxubXm282TrlNb6vVzjrruHfS3Mkc7trY4fFAtBAoEWANwB1A8BopsmWCNFqeVW2vckDntP81/Qj/6juvtDRr4UvNZ/wBdtYHLHlO8udhcPKYmt6M0rP8AMzfNxkag8SNe7r89mwmHs6Pz3ZdmGe99nTeun5K7BlnacRka8NNDnyeaHW6SQCy/rpoHSN3QaV0OIjljGWcQzwOo5RG1oyGqLW1pvFOadCRYF2ukk59MX20vInlrLhZGYfEyGTDPIa179XxHqDifir1eZoFEfBdr4rw7lVsUYWUNYScPiG87EXakDrYT1lpI14Edq9N8nW1TisE1jzckB5o3vOX4JPhouXy8/uN81usEeiftyf8A2OWUHLAwR6P9Tz/5uWUHLi2yA5TDljBymHKovtVyu0PcoZ1CR3poelBcXKqV9Ak7hqe4IzLFx76afrFrPBzg0+tFbPDmmNB31r9o6n02vHuXG1hisVI5xuDCl0MQ6i9pqR+vWXDKDwaCvV8bizHDJIN8bHP8Q0leL8loOfxLLothHOOL9W5tGtLj9pwN9i7fF/XPv+KIOTssxJMkcb3Ggx5dYO+nEAhpribWt2jDJhpA17THiYHA9hrVrgev8/OvSzHz5kBaGyNtoy76bVG+x1nzdt6XyiYQSYTB4uv5jT7nceILS4eYtP3iuv5ZbDauJfiMNBisOGl8mRjg6zo85HDSrpxI3jrUcZG5zpXEjoUSayk5qA6OY13WuZ5J7chMUuAmcMkwcGneAXCnNPAdd8VsdkYR+HhbE57XdJ5NWXV0coLiBdajTRY49ejr+smklMJUtIihTQqieVIC1vhsofJ8xd7UDZbR1V4n2ouNDlrTgrcLMWODw3MQCA3jbSPzW4ds5h39Xafaoe4Y/wBl3tTTGHjcGZcNzZY7KXxXzgyAfDc8OPxrIb50ppWumgGJkcxoiAD4TRA1LQ80TruNDhotixlAgOdTtDZcR6Vym3Noyx1mZnLHAOOmcRNNmi4G+jl++PDcuzE/F1nDKaPu97bBJDmzaHTTo3e869nVare8t5zLiOeBj3fzAGu5yMCw8CzV6rV7P5SbPfYe+WN3VzsYyg9pjuwtvgsThiTzWIwxa4al3SOYa0YyPHerepmYuM/Y+AnA50GNvRcbaWtmGhB0GvFQj2dPzz42xvBZ0yGE5zLR6J6WXLqCs+Db2WgcThnjdlDK81ErHwnLKXBudGxo5sjnGlscrrskOF0Lro61XSCk8cS6mx5t3ujMyQEimPdVdpB1O9ZrHROYSXHKwiyXHPZsN1Op6x5uArQ4/l85785wjpZOxsvHhZA8yxpeUkkrhI/ZkmYdbZmjcK3FLJ+iWt3NtePDtcZn9G6ivV8gsgBo3nd4dy8z5QbXfi5WyO0ZeVjeprav72ovw4KO3MdPj8Y7EGAsbhwIyz5uNuY6uNAmy40OrdoFiYtuUNNfBIv/ANf9qzOcW3Xs2zKjwmHZE34UQe9pFh90HNsatG/7xVUZ58l5ZlY40GfJYabQdQsU53V1nsUOSm0DNBA1nwog1psWHx0Qa3a5rsXpmaetbbG4I4dkvRAOskLLdm3auLTuAd68o1drkcPyweHYTCXWePEOZ25HNffpYPMsjyUTlsuJj6nBsg7wa/MLW8qcQ58eFhc1okFyODLIB+C0XQvXP2q3kbCMFiDM+Yua8GMjJQa0mwd5JogKdzeWub7egvxLIS9r3tHTc5uYgUx1OA9JUTteLqeD9npepYG0NvQB+ZtyhzMuUdEBwJINlvWDX9IXHbR8pb4XFowDGubu5yZ7r7ei1oIXPn4tjV7x342uz657mSH8kP2sRuilP9OX/wBiF5VJ5XMfrkjw7Bu0ZI413ueVDA8utq4uQNbiGxssZnMiiAY3r1LSSeAv2rf0xnzesN2lKd2Hk/qMY/3FN2IxVf8AxuBHTcd2utMNLmJNsBwp2Jm8JJG+hrgPQsV02GcKc97uv+YS/wBJcp9cXyrqJcXih8IQxj67v1Oasc4lxLS/EwFocHU0s1rUCxI7sO7qXORYbZ4OYRMzG7IaASTvvXVZbJMNoKIA0GmgHgVfDk8q33KDb0AwsrRKx0kjHRtaxzXOLnDLu6gL3lcD5NZAMS+xvZddgOvoKw9rYZkWIfzerJv5jftaFzdfrAHuK1+y8e/CTiRnwmGx9aJ28a9nqWuecnpm3XsexcIMzwMxjbpbiQM763NJ1prSb7+1cl5SInQ4aPD2elKCGkfJYQXDxdSzMDyvgYwyGducigHNDXNP2RqSB2HeaoErU4nGu2xi2EXzUDQTnOuUbgfrOIuh1Ctas6Q4IwxoAAFADQV1JrfN2N2DzqQ2Fe6/CysmOejGnifWVIrenYJHU79+CR2GT1HwQxorTW894HcHIQdbJhGH9/8AKodgWnqP78V0Zw4UDhm8FvE1zLtnjh60js8cB6V0pwg7VE4McSmGuYdgwtTtvk+Jm2wgPGmu5w7a3Ht9WhHduwI/f/6onZw7PMrIa+auUPJqaJ7ssT+JDWkgHsc3Q/vw0w2bO41zUni1wHjYX1PLsZjt7WHvCx3cmYT/AKbPAFa9I8c5G7LwuD/nTPz4gihljkyRg76JaLcR1+A4np5eUGH+t90/mu0k5JwHc1vnd7VQ/kdF2DxPsTOTa4SflJhx8V/3VgS8qoPkv8dF6J/gqH5Q81qmTkHAfjD7l/mpk/ptebS8qYjplsHja1r3RzsIG4abtRwPoHp4r1V3k6w53uHgwfmVJnk2wo1zG/qhoKsyF15byc2xzBMMoJaCDQJBvqcxw3GuG8ej0bB8qsIzDvYB/Md8aQOc80D8ZxJdVmszgBZpZE3krwT9XPn/AKXMHpyErJwvkv2cyswmfXzkrq8zQFm4ryjaWOLpTI0F2t3vGm4A9dKn3fOdwPpXvEfJPAtAAw0dDTUEn0lZMOwcIzdh4vFjSfSFlXz6ZcQf2VTLgp5dHDMOB19Fr6UjwkTd0TB3NaFe0AbgPBPY+ZI+Ss7t0JPcwlZsPIvFn4MMvhG+vQF9I32J2OCex89Rcg8ef9KXxaR66WVH5ONoH4jh9osHrcve8wTDgnseHQ+TDH9ZYPtO9hKzoPJhjh/rQjvMh/Jex5gnaDyR3ktxcgqTEwitRTJHEHjeYUqH+SHEurNjIiRuPNOzePT1XsWZFoPIofI/LpnxrK+rA6/OZV02x+QDcM3K2d9HU5RkLjxNOXcWEaIOfj5Nxt+NIftOv1hZLNjxiqaAR8no335atbdKwmDB9yDgFB2BB6lsEwmDW+97eHrSW0tCYMbOnmVeiRrirqYszpZ1SXBSDgmmJhxTzquxwPmSDhwTTFvOd/oSc/vUHOHBRDhwU1QXfs0oFVSu7D+/FRimGu8deuiaYtJPFLMjOlzg4ehTTD5z92pc5+7SzDsSvuTVxLnUxKVWe8IHemmJmc8ExMoZhxHoUgU0xYJFISqoXwUs6aiznOxPOqikQmi7Onzio1TCaLucRzhVSE1cW5ygvKqTCaLM5Us6pQEFpeUudUKTKCfOJGQqq001E85QoITRS2MHr9anzQQhBMBvBDpAOxCEFfOdqRd2+tCFnVTUShCohv6/QoOiB3IQoKxC4bt3gkQRv9CEIJMcDuPoUh+9E0KKMqRaEIQAjCMgQhBMN71IM7UIQMN7SptHaUIVRLIlzfamhBHIeJSDTxKEIIlp4+lSa2t/pQhFSvrQEIRDagupCECz9iM/YmhTQ7QhC0P/2Q==" alt="Volkswagen Fusca">
            <p data-info="90.000 km">Volkswagen Fusca 1969</p>
            <p data-info="Preço: R$ 50.000">Preço: R$ 50.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Clássico">
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/22/Chevrolet_Opala_SS_1978_Inca.jpg" alt="Chevrolet Opala">
            <p data-info="135.000 km">Chevrolet Opala SS 1978</p>
            <p data-info="Preço: R$ 90.000">Preço: R$ 90.000</p>
        </div>
        <div class="catalogo-item" data-tipo="Clássico">
            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExMWFhUVFhcYFxcVGRcVFRUVFhUWFxgXFxgYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQGislHR0tLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAADAAECBAUGB//EAEcQAAIBAgMFBAYGCAMHBQAAAAECEQADBBIhBTFBUWETIjJxBkKBkaHRFFJiscHwBxUjcoKS0uFTssIzQ2OToqPxFyREVOL/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAgEQEAAwACAwEBAQEAAAAAAAAAAQIREhMDIVExQWEi/9oADAMBAAIRAxEAPwCw9plUkMpIBMZSJjn3qs4ewx9ZR/Cf6qHavsy+FRI4ueX7tEtXXUeFZ/eP9FQE+isqjvqf4TzP2qWFDsJlN5G4+qxH1ulOmOZhGQDWNX+Oi1K0txVjKh1YyHM6sSPU6xQOcEykkuNTPgIEwB9fpTW7zklSV0jgeP8AFUvpjsSDbTQAnvmNZiO59k0MB8xbKu4Ad88J18HX4UEruEYkNmXQEeE6yVOpzfZofburBQV1BMweBA59fhRXxbd1cg1kTm6cZWgmy+YNC6AiMx4lTwXpQWDadisuujA+E8DP1ulQvYm6o/3ZJIHhYamB9frSvYhhEoN4Hi5sBxXrT3sPceMqoBmU6ufVaTpl6UVB1uOCCyagg908f4ql29xBPcJUEzlYTp+/U7mdfUU/xn+mgm4biwFUZgd7HiP3aCzbe47RKj+Ekf56HeR7ZAzKZnUoRrP79Gt3zbE5QT0bj/LU7WJN0f7MbzHe5Ej6vSgpWb1xpJKeJh4T6rFfrdPjRRhiWJLDXkpiQI073QU9rCOgIJQ94tvJ3sT9XrTJiXJyhF0A1LERJMep+ZoIWrTMzAkALHqniOWajjANmDZhy8J4kH63SjrhLgLHud6D4jwEfUod7HOpClE1G/OeED6nWiKt8OGyyIgnwmdCv2vtUa3hWKglo1kDKOHtqDXGZgSE0UiJPEqeX2fjUMVtFkgZFMmJltKAOKxt1IAI1aD3R5UU2muqyu5ggzAUbxH1fOg31Z4JyiGB0B4cPvoj4l1VjlU6TGvAc6CvfRrc5WOg00Xd5R50JbrmJY9NFH+nyq1eJaJy7o3H51EWSNAR7jw/ioKJzJoCdSTuXedeVXcEXYSzned2XgSB6vSgLhy2pYbyPCeDEc+lWrSuggMsST4DxJ+1RRvoYktLzumRpExw61TuG4LhXO24Rrzkb46Ci/S7gJEpwjunWemaidgzHOWEka6aaT86IhcweaCxYx9oxu/uaqYtCsZWYSYjM31W69KIMRdJC5gN/qjh+eNFtbJLkM1x950hAIgx6uh1oMkEmZJPmx+dPfBAMaQDuq7i8DkJAZt435fkKZMFmmXaPJdZ0jdQMuHWOP8AMRSo3Yn67f8AT/TSopsNeyASjbhPh+dGGKzAEI0Hd4OP8VCe+jGVzEH7L/KoYd4VdGkAT3H0+FVBcKSJlDvP1Tx/eq2cbppbYmYO4R8eR+NA+kj7Wm/ut8uR+NFwTjvkhxroTbfXuqJ8O6QaCNvPJY2mHdGkpwLc261MYiTGRwY+xumPredWPp1uYLHnGS5P+XqKqtdXPpmiPqPz/doHvWnYqRbeBqTKRqpH1qG+KykKUbXdEax7d9WV2nbA1J5Rkbfw4VSxmJDQVVvFr3WmIIndzNQGu3WZRFtjqp9UaBgTvboaO+0Ag1tuPYpHLg1CTHIkySB1V93tFA2jjkyt3oIBHhbfrHDoT7KC9exBuDu233CCcu/nGaquFRkADW2kAT4eXA5teNTw2OQDXMBofC4/CjfTbbqCCTyOV93uoGt3c4BVGMgH1BoRp61CwTsi6oxOYzGTcSd0uPyangbyqiA5hCie63D2fmKJh3znuB31jRH3+cUkhXxO0X9Sy5G6TlmROgAY++mtX37TMbLgFVBBKSCs8M9XRsy6Af2bCSTqMuhPWijCOBED2ug/1VnlH1rjPwx2sNxtXAYH+HEfzdKBjGLFWFsgAGZKak5SOPQ0VsAxMyn/ADLfXrRWwrxEW/8AmJ86c6nCWaMVBAyEkyd68I36/mKjicK9xQQoEHiw51aXZd6ZCht+5lO+g4zHvYEPZPv+VZ7afV67fD3nZYBt8tZHrED8ajdssQQFEkEb9PurJxPpQr+pxG4zuYH8KivpWBP7P41eyv067Nco41yr/N/+ajavlgDlGo5niAfq1kP6VD6lAs+kSgABdwA38gBTsr9OuzbyMogBZknVjGrE/V601i6zmCqxJHiO8Eg+ru0rJPpGpPg+P9qfB7etpMqTLE+8zFOdfpwt8a96ywMwOHE/00641jIAAjqTO/p0qle9I7LTow91BsbTtknvASIE6c+nWtc4+szSfi8oYNm7u4751kjy5Ue7tF1iBb1ng2kfxVVTGgxAkQdxHCPnU7lhnggAAdf7VpErivc1LLrG5Dw83oWIuMi6FTPNSP8AVUUxjKPDMQPFG8xy60r2d13KD1JP+moGzXPs+4/1U9PmuDSF95+VKmAOzr6gDvrozesBpmPM+VXLmJThcX+YfOg3LcCAI1nTmd9SwSE+QY/Fia1CIWryZm766kHxD6oHPpV8YxP8Rf5h86neMqQTu38evy99cnsbabXnckGO6ZBPdDAsgOU78pHv6VJnPQ3r+IQODnXwt6wGsr8qmmLSP9on8y/OmGPLgjXXd7Kri7DqeOVh8V+VUSxeISF76nvcGBjQ9edUdq7SFpA6uJB1ht3mYIA3amOGoia2bd2edYHpUkqDIkayyBlUBgCWZgQo10ABM66gGpIxrPpMXQ5xDFTEEHQroDuJMETp7t1F9KNpqbZGdd8lfWlXnQg7oB0jiaFs4BmyZVZUCZTLqIjwkbsw8hVf0qtrIHfALN3hDgGCYGvJTw4Csz+J/FvYe1Q695xOswdBy4mtzZmLXKBmHvFc96NYJLbx3lkSPDBHKQupHmeFbG19qEEWbOtxtCRplHnw6mq0JtXbhUm3ZBa5zHeAjfoQZ047p56wM7dxTIBcuX2biB2CKOgLo5PnA8qDsfAhCxJljAJPGNdBwEMNPs1rt5/dRGDe2hiD4VeftYh591kW6pYnEY0eK7cQGNFu3yeXFia6R8UlkNcY8dOpyjjzqjtXH2bqG4PGBCEFlygnxsAdfbzpBLM2S2JvlgcXcUqwEM73GbuhtAXAAg7yREGr+It3soCXwwJILNcxPnpldYAiM2hPJQSCktrYGRfG4XtTMwdZSd88+UBeDA6Fi5FuOZkfARQcZgdpXrtwpojDNLG9iiO4T3e/dca5TwrdTHXeyv8AakHIgC5SSM7sQsEqJYAOd3qrM7zz+KmzjMqrJa4r6bougaecl/jWrtPFIlqyr+G/cN24TI/ZmLVtuhCZm86xeInIbpMxssttnXzByhZjRr96ZjjqRPlSubGxIBOTNHBbt4k+QJFa9nabGVuZQylRAYEyCJkcI9tamHxixqw94rfGGOUvOr2OYCQp3Tq13lO7PXSbO2WbihmciVBhe0eQ2oYMHGnDdwrJ2vaCXmiMouEzvGVv2nwD3B/DW/6P3+ytjOfAXssTwKkNb9mQ76kRGtTM4kuyFAEs8kf8XQ/za1Qw4ElXkMujavEaw6iQcp+Hs1s4nb2o0ESRMz1BHLjvqni8RnyvbgurcwJQk5hrvB0++pNYn8St5aKYMa94j2XT/roF+3cU90dovEgOpHSC5nSjYLFBkBHhO7mI3qeREH3GoLjgGYbtRBPEdPjSIrP8WbWif0O1tC5ZYPkuKk6kkER1TLJHk3sJ0rsLO3FyiFJnUZYiNOM67x765Y4hWBU8aBgrhtt2ZPdach4BjvQ9Dw6yOIFWP+TddPfxwbwqd4nw8CDz6UX9YQBKNw+rxP73OsJcTl3yPYflRTiZEAMdR6rcGB5VtltfTjwRven9VKstcR0b+VvlSqAex9pWrnhyzJ0YCee4irOJ2vZXMsLmgwCoAJH2t1chsKwoTXmTv138x+FQu3lJYS5VvECS5gECCzEk6MNNBoRM6ipLTv4hxqFBUgN3TDd5y5uEkbt+gMRA4VZ2ViVVAHtrnO9gPEYElpGj/fvG/ShhLAVYLE6kyZnXmfW9uvPWj4a0J0OmVdxOviHt0FSK+9GlmQldBvOkDkflRE2pZQ5XUTmKr3ZJGVWmANPF8OhrCxpusSti1dJXTMEcgnXQGOh1B4jXhWc/o5j3I/ZsMu4s6iBGsd6R7qTb2e3XvibYIXukkg7hoMw1Pnuqxib1sgAgQTqAgYuDoEEDWdSY4KZIGtczh/RLG6C5ctBeIZ26Dguu4VsJ6PPCxe1XdlV2Gu8bxpuqTaGuMs65aZiHIQBVZSFy98wDnBXeAZGU7u9E1S2rjit1riAHJIKncSSTG6CQDPHefKta16JsSCWfQkwCq6cBGukknWtcejAL9pALSGAfvop3gBAoWBuHxk61nnC8JYaYxsvctKWO4gbpG8gDeOVPsrFpZBa7au5i0M5ttrO4d4DT8a7yz24H+6kcBbCg+6YqljcVfZWRjaKkZWXKjBgeasBmHSpzhrrlztzaZyxbw7zJ1a043knLoh56eVBTal1Wk2DE6jsr+nDeLZjdy411NrEMmqmCRqCqgkjT6v3k1Z/XTgaj2Hsz/op2R8OpxG0NpZritct3VV1IRYuKGcBhuZR3ZCzHLqYAuKW0AxYh2IKhuC6g3CPZ3RzGbcAG7PH7SW4hS5YVlP2UtkHgQ6rIPURU9n7SRAJMDQd5s0ADnmlj1gE1J8kHVLz+96QLIVW3SSTkLEiMqrmPEzqQfjNEv7cVcslhl1O64sxy46ndXd43amDM5ra3PY5/zEVjYz6A4P8A7VQeYS2PiZNO6p0yz02lYxi2ltWiMRIV7hVQSzSIRh3oANxxO7KvM1z3pheW9fb9qiIkIobtNUVQqsAiHQ6nzNdJaa3aB7C3kaCAxgxm0JAECesToKyU2OnMnXmx3ajTNzqdlZnZanxzEYt7B2el7GDtMQltCodyqsztmVXdllQAoNySWIIynu1P0mS1hnAsYy3dtMgKu5YMWOreBDJkgzp4oigHCQTxLSCzTnggSoPIxrxgDgSKG2AQwCqmN0gNE+YNWfLVmPFLIvbStOSWuWwxyAH9qRCl5n9kDueK1MCVexcVbivqgzLm0LKyZmDKDOQCdPVo6YZB6i+wKPuFHAUdPaRU7a7rXVOYwV2VmMi9aPSLp/0VZw2ybqnxrB5rdUfzMlaqMOZPtJ/GprlBkATzjWp2x8I8P+qmEwbqzEshVoPdJbviNQcsa+fAdaJ+rgSTmid4yhvMeMGJ3eyrXa1Esax2TrfXGe0U2eun7Q8v9muv/dqdzAqwyl2I/cAPv7TQ9ajFStISYgnQnThHEzuFai9p9JwrCWJtwogs0BczFQCSN7ZVJjdPSaGmLUesI86icRBjvT5Ej3jdXObYxT2rzAccrDdoDy9oNdKW+ud6xHuHSNjVnfSrm7W3TAkgH89KVdOTkqB3KAK28gAgkb9w0E9PbXouwP0TM6pcxV4o5g9naAlPss5kExAIAjTed9ebYW+bT27ogFLquN8ShUgFd8aNpPPWvfsV6SXrWHW8oRwFYsSG17ttu7lYQIbrWcmfxqMj3KGD/R5hE1YM5iO+zH4EwPdWrh/RTCr4bYXyCjryrA276V7Qw62GbBo/agmEN66y6IwzFCBbMPuIPh3msm5+lG9bE3Nn5Bza89r/AD22rM0n61F4+O8ubCtAcfh8qCdhWzz/AA91cSP0w2YlsPc0/wAO8lzXdvNkUS3+mHC//XxXvsn74rM+OWovDrX2BaXUlV6mF+VI+j67wwgiekH1t+7rXKYj9KGz7oC3cPiiAZgrZI3RqBeEjXdTj062fcRrWEDJevBbQDWwsgtGXMLpgQzD206pxexp2cDduybSqLfB3mWHMKDoPM0X9S3OLE/ugL92vxrUtbew1lFS7cCkKpMK53iRqFIE0DbvpDYGDuXLV1SCwtlg3hLcN2hK/fXPhbNb5xuObxmKsWyVZs5G8CbnxJy/GqNzboGiW4HWB8FH41gXsYrklIgGD0PKgs551j236auI2m7byo9g/GaqPjDxYn2kD3CqdNUw1ZN/8/330NrtCAqUVcNOXps9MaagcmnmozTE0DzTUppZqIVInTQkeRIkctKgXps9UKzhlBLAanfvowoIenz0kWRT5gKDa1nWAASxO4KN5rncbt64xPYLCjcxAZyOcHh7K1Wkz+M2tEOoN2hm7XMbK25cdstwhp3GACD7NCK2S9LVmq1tEr4vVzPpOQ9xYIkIB10Y6fGtR7scazWxD3ES2xBVWzK0EkZgF1M6DWY5k863Rz8k+mTZLQISaapm2x3bumaPuNKuriFbud4TqCCADuUkEAkcQJJjjXu2w8VdxmAQtqzKAWjLuDBn3arK24MazXM7C/R9h7dw3rxe/ZBaLKoMwIYgGS8XIjURry4V2GC2hgbKhVu3LKz4Llu4qakzlCWu5vnuka8a6xExOpsT6Zvpzc+k4VWeyT2TKxZCF7zg23Vu6T1g8q8z+l2rZi3fuWzPhRAWmeYuqPeK7XZ21LmI2izHaa2EtZ1UXGNq3fVb962o0u2zn7M22mSTIJnj2D7Nxzx2WPw9wHg5W6SP4zcmkkennWxdsWLa3PpBu3y6wpu3r1nLu0HZFwJI8Q14c65z6e5/+XYbzS9cEfxWDXrOI9GMaDNzZ+z754N2dpCfNhaUj31kY/ZSrpc2Rh1nhbcg+zJiFPuHCpxk5PPxac6h8I2nCzhrZ/71tTRsFimt3EZkwsI6sSHwiMIYGQLbjXTTSuqGzcBI7fZl2ysgdobmKyBmOVBqXmWIHtqti9lbKE5hiLakkBrLtcRgO6Yz4UggGRIMSDBpkrsOy2xs9bq2AWibltXb7AYjWP3AOEVs+lWyrV3C3kU2rYgMT4UBQgS2mggsBv4Vz2xtq2MTacO4mSF0LkAxvRe8GlZ1HHdrWhhxYe1cUX1LXLb24h8u4kEqwLLqB5a79BV/ie4trzi3hwly6vaW3LAMAjT3kGrcssZ/eKsW7SkeMDzn4VQZUW6rhw2VMr5AIIJMkEkH1hvHCp2roI0IMV4bVnH0PLaJvMxO6KRUXICl2IVBvY/hStiTqYA1J5AbzXJ7X2k2JeBIsp4VGkwPEZ49eAPXXVK8nG1sXMV6TqDFu3mHNjE+QqWD9JlYw65eoMj28qwBcjdlH8IIjzbWnuWgyllGVl8SjcQfWXpr8RXbrq5c7O6zyKjmrC9HMWSmQnw7vKtZn61wtXJx2rOxozNTFqrNfHP3a0xvefu+dTFWS9RL1XNw8veaiXPT76YaOXpi9ViTz+6pJZY7gxHtj5VcTRs9IXRzFVrrW1Pee2I5sCfcsn4UFtqWEEhi5HBVKg9MzgEewGtRSU5wJ6RX8qJYHicdpcGmif7tTO6fF5FTxrGu4JhbF4HXPlMLGRoJHenXdxq3sPaoOJuXr6C4XVyVLFBzhTMiAIA5CK2Nl4zDPfAuWXXDlxcZA+ecinLqQNACSTOsDdXaIz04TOzrnsMv7YECA6h9NwnxeyQ1bTXxrEtAkhAWI843e2g+j+xEvwHZlyWkPdIBm49xgDIPCK3hsBVBC4i+Ad4DwCOoAg1Z8fL2Rfj6cljsdMqNBOvM/wBqA105Qs9Tz1GgnlqD5xyro7vonZAOV2nTxEQPPTzqvhthWzLMzEsTrKiQSd4y6bh76cc9G77YOVTqx1pV1y7Ds83/AJk/ppqvGWddHY2yyggM29jox4sT+NTsekDIQc2YSZViWUjiCDXPm3REQwfZ/f8ACtTO+kiMXvSQYbEPbxFq2BcGly2YBJA7lxc3dc6ZCDOYFZGldT+jzBLZuucnZC6kC0VgMUYuGE+sFZ1I4gKfPhyKcYq7YIu2GKuhJ03EEEGRuOh48qzWMmGrTsS9xt4K2AAqKAN2g0A4bqr4/AFrdxLbOrurZDndgjlYUhGJWAYMRG/nXkP/AKw4y2QLljDup+qLiH35yPhV/C/pwXdcwRH2kuzH8JQT767zarjxs5B/SnHYhOyNtnOZDKWlLZ7bh18NufEu6eddR6J+kmOt2Rasm2bdoAKrG7bcKSdDkYSV1BGm7zrlLnpRh+3uXUS9bDuz6ZGILMWIA00k860tjbWsPeLpebO+cujWZVs2rZoYgd4Bt++vPN7O8Vq7selOMcZXwth93rXA3Pe7mobU23irjW2XAW7eU94ILbdoCR3T3ZG4e0DlXP39r5GDBt2khLpBHXIrEVfwnprZ8LXE5QwdJ9txVFc+zyfG+FPrkcbYdLhzq0gzlYaCd2h37z76BazsxYgKOA0H3aKPsjSuu9JNo2cSi3FZS66SrI2deRyE6g/jz05C/tFFmW1G8Df5RzqTa1o/FiKxO6B6SY027Itg967v6Wx8zp7GrLwGBzhV5jMfLXf/ACtp9laobSxDXHLtx3Dko0A9grb2ZtAqdDByKR1yO7e/vf8AUa6VrkY5zOzouBwee8bbQdGBBjL3N4nhGuvSsrD2MrqNYLNaM8QdBP8ANV98T3tNJ8TxqQd+vGlexAY2Rw7R7pPHIiqqeyLZPmTVRn7APfI6V0Gg4CsDZuiTnykk6xOnvqy6gyWusR00+dZtTZ1ut8hptdA3wPMgffQX2hbG9x7AW+4RWLduW13CfM0E4vkKdUHZLbO0l9VbjewKPfrQbm0X4W1A+0WY/AgfCs2zjiKOcUSN9XjEM8pHGOuEwbrKP+GqofeINT/ZHV89wji7E/dWY181MXSaqLV57H+HHkWH41l3wMxy7uE60R5NQ7I8q1qI2TDb468q00VoMkqkQWYQAp3x9ZjugT51m9g3KpphCaitbAbUy5yBGYiByVRlQewVb/W88KyreGqwlippi6dpE8KimKIoHY1Psqmriz9NNKq3Z09NMdj9HNOLHlu/vw8qkPOlIGvWtsoCwOY+NTKKOP3VF01oV5NKuDC25sRGk22A+yZ39CB8K5O/gLinVT7Nfurub9omqT2OtXE1xvYt9U+41t7Jx4srC2pY72beekRoK0zaqIs1OJoZ27c+rFBv7WdxDKCN8HUTV9rM8PhUDg54Uw1mnabDQCAOA3CotiDc0O8DTrHD88qu3MB0FBOAgyN9XBkY63x/Ov8AeajbaVBkgrxHDhPkRA9g51q4rDyIjfwrEdSjb4NSYWFntvrER0iT0AH40fF3yqkto9wBQv8Ah2hw6E6fE8appjHG6AeYVQfeBUrVskyQSTxNZUNWI0qZuGKsi1U1sU0xmspNOLJrUXDUQYXpU1cZaYc1bSx0q8uHowtVJlcZv0bpRUsdKvdjUhZqauKHYdKkLFaHY0uwNNMUUw+tWhZHKjW7JmjLbPL4UFEW6KqUUW9d1GW10qCrkqQWjm30pC3QAyUqsi1Sq4jo1jgKILR5fCr+GEnQVpjBmK7RDGsQIYB/PWgXknjW32EgjkeP56UFsHOkCoOcvWetV2sDlXS3tmdPhVS7s8jl8KYME2RwAqHZVoXLBmhNbPKpoq9gakMLO72ijhDypwpBmKaYqthqQwgrQIESFEfd0p0I+qPj86umKP0IDeKg+BU+qK0GHsp1QdPdTRl/qxPqj4U/6sUbgK1uyFMbcVlWV+q14b+XyPHy++o/QByrWRDRQD6wn26/3oMX9XjrTfQK22tjh99RCCorGGB6UvolbWSnYDrUxWKMIakMN0rUKU3Z0Gd9GjhUls1fC8qmLY4/CmDLaxTdga1XtDzofZVRnLhzNENrpV8Wo4U4TpUwZ3Y0vo9aYtzSNuriM3saVXzbpUGzs3xCuxtYQ5f7CuN2d4hXdYTG93vECu9HOWHdsxcYEafj7Ok1atYKTuouIcM7GeAPuIn4TWpbCkCJ9gn7qREJrPvbNEcPdWbiNm1091fP2g1n4i2TuFawcFj8NDGqnYV0e08MdTFUcPhSa5TVuJZJw1N9Grc+gnlQr2Fj/wAVmYVjBcv4jmKcoB1B3fnnVjE2+NABjyqATmmQ1K6vHhTKlBLN0pTUgnlTRQOhqVJanUWEctIa9Pup6QoqfZHlTdgeVOrkcaftfbREGsmom0aKb9R7UcqCAt0uzqXaU+eioRFNUpqNEOts8NfvqQSkGinzk76BwlLLSzUxNVEuzFPQ5pUF3CjWumwOJgVydp60rGKI0rUSkw30u97f099XcNjdBrXOJiDvqxbxH5+NbiWZh1C4sEb6r3sSONY9u+ahevGtagmOykHX41W2aqmq9+9pQ8Heg1NVvdivOqG07GUUWzfPWpbQaV/8UnMIclizrVSreMXWqRBri6EWjyqJqQFMq6wd3CoFNKiC1T9nVDKKnSAHKngcqgalNPTk0EImolaKGpGghknofh/aospG8USTUlbgRp8R5GgAAakAedEa3Go1H538qaRyoIEU8U8080ESKQFSmlNUICnUxwHt1qM0pogwZfq09V5pUFm2KuW4qohFFV6C4sVYsEGfZ+PyFUFuUezc19nyrUSi+HqDtQlu0z36umIXJqFsGmuXqgr1NGhZJqeIuaa1QW9TXLtNMUcUJNU2WKs36rMay0YxSgGlmpjUBbTDcfZUj5UAiiKSfP8AOtEPFKkDTE0U5phFNUSaAsipG31oANS7Q0RPLFSmhC6eVP2lAUVFknofgfl93lUM9SD1QM6UpohFSWyDuJ8txoA0pozWaj2YoB0qLlHKmjpQDilRMtKgZaMtNSoDJRrPiHt/ymlSqiw1DelSogZoYpUqKIKgxpUqCveqo1PSqKiKktKlUCNSw/iH54GmpUROhmnpUDLRIpqVA5qK0qVA3OktKlRTmnpqVBOkx0pUqIK26oDfSpVQ5oVKlQGFKlSoP//Z" alt="Fiat 147">
            <p data-info="100.000 km">Chevrolet Caravan 1976</p>
            <p data-info="Preço: R$ 95.000">Preço: R$ 95.000</p>
        </div>
    </div>

    <a href="PaginaWeb.html" class="voltar">Voltar</a>

</section>

<script>
function filtrar(tipo){
    const items = document.querySelectorAll('.catalogo-item');
    items.forEach(item => {
        if(tipo === 'Todos' || item.getAttribute('data-tipo') === tipo){
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}
</script>

</body>
</html>
